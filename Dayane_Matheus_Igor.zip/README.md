# Vaccine Shell [College Project]

This shell was developed for the Operational Systems course at UFES - Universidade Federal do Espirito Santo.

If you want to run it, you can run:

```
  $ make
  $ ./vsh #In this project folder
```

Made by Matheus Lenke, Dayane Erlacher and Igor Dummer